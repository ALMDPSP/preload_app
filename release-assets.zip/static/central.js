/* Central workspace: saved base and checklist share a screen, never an implicit write. */
let centralData=null,centralSaved=null,centralPdv='',centralDirty=false,centralSaving=false,centralLoading=null,centralSequence=0,centralRevision=0;
const centralClone=v=>JSON.parse(JSON.stringify(v));
const centralPdvKey=value=>{
 const match=/^(?:PDV[\s_-]*)?0*([1-9][0-9]{0,3})$/i.exec(String(value??'').trim());
 return match?match[1].padStart(2,'0'):String(value??'').trim();
};
function centralMachine(){return centralData?.machines.find(m=>m.pdv===centralPdv)}
function centralChecklistOpen(){return !!(currentId&&cutoverEditing&&state.meta.branch_id===selectedBranchId)}
function centralPending(){return centralDirty||centralSaving}
function centralSyncBadge(){
 const badge=$('centralSaveState');if(badge){badge.textContent=centralSaving?'Salvando tudo…':centralDirty||dirty?'Alterações não salvas':'Dados salvos';badge.classList.toggle('unsaved',centralDirty||dirty)}
}
function centralIdentityGuard(){
 if(saving||centralSaving||executionLoading){toast('Aguarde a operação em andamento terminar.');return false}
 if(dirty||centralDirty){toast('Use Salvar tudo para gravar as alterações antes de continuar.');return false}
 return true;
}
async function loadCentralBase(force=false){
 const id=selectedBranchId;if(!id){centralData=null;centralSaved=null;centralPdv='';renderCentral();return}
 if(centralDirty||centralSaving)return;
 if(!force&&centralData?.branch.id===id){renderCentral();return}
 if(centralLoading?.id===id)return centralLoading.promise;
 const sequence=++centralSequence;
 $('centralFormHost').innerHTML='<p class="muted">Carregando cadastro da filial…</p>';
 const promise=(async()=>{
  try{const data=await api('/api/rollout/branches/'+encodeURIComponent(id)+'/context');
   if(sequence!==centralSequence||selectedBranchId!==id)return;
   centralData=centralClone(data);centralSaved=centralClone(data);
   if(!data.machines.some(m=>m.pdv===centralPdv))centralPdv=data.machines[0]?.pdv||'';
   renderCentral();
  }catch(e){if(selectedBranchId===id){$('centralFormHost').innerHTML='<p class="sync-error">'+esc(e.message)+'</p><button id="centralRetry">Tentar novamente</button>';$('centralRetry').onclick=()=>loadCentralBase(true)}}
  finally{if(centralLoading?.promise===promise)centralLoading=null}
 })();centralLoading={id,promise};return promise;
}
function renderCentral(){
 const host=$('centralFormHost');if(!host)return;
 const branch=currentBranch(),data=centralData;
 $('centralWorkspace').hidden=!branch;
 if(!branch){host.innerHTML='';return}
 $('centralBranchLabel').textContent=branch.code+' · '+branch.name;
 $('centralEditBranch').hidden=!DECIDE;$('centralAddPdv').hidden=!DECIDE;
 if(centralChecklistOpen())centralPdv=centralPdvKey(state.meta.pdv)||'Não informado';
 const hasBase=data?.branch.id===selectedBranchId;
 $('saveChecklist').textContent=hasBase&&centralMachine()?'Salvar tudo':'Salvar checklist';
 if(!hasBase){host.innerHTML='<p class="muted">Selecione um PDV para carregar o cadastro.</p>';return}
 const m=centralMachine(),latest=branchProgress?.machines.find(m=>m.pdv===centralPdv)?.execution;
 const execution=centralChecklistOpen()?branchProgress?.executions.find(r=>r.id===currentId)||latest:latest;
 if(!m){host.innerHTML='<div class="notice"><b>PDV '+esc(centralPdv)+' fora da lista prevista</b><p>Use <strong>Salvar checklist</strong> para gravar esta execução. Para atualizar também o cadastro de implantação, inclua o PDV no plano da filial.</p></div>';highlightCentralPdv();return}
 const disabled=READONLY||centralSaving?'disabled':'';
 const assignment=(data.assignments||[]).find(a=>a.pdv===centralPdv)||{pdv:centralPdv,version:0,executor_id:'',validator_id:'',wave_id:'',planned_date:''};
 if(!data.assignments)data.assignments=[];if(!data.assignments.includes(assignment))data.assignments.push(assignment);
 const recordOpen=$('centralRecord')?.open;
 host.innerHTML=`<details class="central-record" id="centralRecord" ${centralDirty||recordOpen?'open':''}><summary><div><b>Cadastro da filial e do PDV ${esc(centralPdv)}</b><span>${esc(data.regional||'Regional não informada')} · ${esc(data.gr||'GR não informado')}</span></div><span id="centralSaveState"></span></summary><form id="centralBaseForm"><div class="central-fields"><div><label for="centralGgr">GGR</label><input id="centralGgr" value="${esc(data.ggr||'Não informado na base')}" readonly></div><div><label for="centralGr">GR</label><input id="centralGr" value="${esc(data.gr||'Não informado na base')}" readonly></div><div><label for="centralDivision">DIV</label><input id="centralDivision" value="${esc(data.division||'Não informado na base')}" readonly></div><div><label for="centralRegional">Regional</label><input id="centralRegional" value="${esc(data.regional||'Não informada na base')}" readonly></div><div><label for="centralStatus">Implantação declarada</label><select id="centralStatus" data-central-machine="status" ${disabled}><option ${m?.status==='Pendente'?'selected':''}>Pendente</option><option ${m?.status==='Implantado'?'selected':''}>Implantado</option></select></div><div><label for="centralVersion">Versão instalada</label><input id="centralVersion" data-central-machine="installed_version" maxlength="80" value="${esc(m?.installed_version)}" ${disabled}></div><div><label for="centralDate">Data da implantação</label><input id="centralDate" data-central-machine="deployed_at" type="date" value="${esc(m?.deployed_at)}" ${disabled}></div><div><label for="centralNotes">Observações do cadastro (opcional)</label><input id="centralNotes" data-central-machine="notes" maxlength="2000" value="${esc(m?.notes)}" ${disabled}></div></div><p class="muted">GGR, GR e DIV vinculados automaticamente pelo código da filial.${data.organization_matched?'':' Filial sem correspondência na relação fornecida.'}</p><div id="centralAccountability"></div><div class="central-record-footer"><small>Salvar tudo grava cadastro, atribuições e checklist aberto em uma única operação. Ao salvar o checklist, a implantação é registrada como Implantado. Os aceites GO são registrados à parte.</small>${!READONLY?'<button type="submit" class="primary" id="centralSaveBase">Salvar tudo</button>':''}<button type="button" id="centralReloadBase">Recarregar dados</button></div><p id="centralBaseError" class="sync-error" role="alert"></p></form></details>
 <div class="central-pdv-heading"><div><span class="eyebrow">PDV SELECIONADO</span><h2>PDV ${esc(centralPdv)} <span class="badge">${esc(execution?.status||'Não iniciado')}</span></h2></div><div class="actions">${execution?'<button id="centralGoLinx" type="button">GO da retirada</button><button id="centralGoOrion" type="button">Aceite Orion</button>':''}</div></div>
 <section class="central-pdv-identity" aria-label="Numeração do PDV">
  <div class="central-pdv-numbers">
   <div><label for="centralNewNumber">PDV novo (Orion)</label><input id="centralNewNumber" inputmode="numeric" maxlength="4" value="${esc(m.new_pdv??m.pdv)}" ${!DECIDE?'readonly':''} ${disabled} aria-describedby="centralNumberHint"></div>
   <div><label for="centralLegacyNumber">PDV antigo (Linx) <small>opcional</small></label><input id="centralLegacyNumber" inputmode="numeric" maxlength="4" placeholder="Ex.: 03" value="${esc(m.legacy_pdv)}" ${disabled}></div>
  </div>
  <div class="central-identity-footer"><small id="centralNumberHint">${DECIDE?'Se alterar o PDV novo, os registros e o histórico acompanham a mudança.':'A alteração do número exige permissão de edição.'}</small>${!READONLY&&(!cutoverEditing||currentRejection)?'<button type="button" id="centralSaveIdentity" class="primary">Salvar tudo</button>':''}</div>
  <p id="centralIdentityError" class="sync-error" role="alert"></p>
 </section>
 ${!execution?`<div class="central-start"><div><b>Este PDV ainda não tem checklist.</b><p>${DECIDE?'Inicie a execução para marcar os processos e registrar os aceites nesta tela.':'Solicite a abertura da execução a alguém com permissão de edição.'}</p></div>${DECIDE?`<button id="centralStartPdv" type="button" class="primary" ${!branch.active||branch.needs_review?'disabled':''}>Iniciar PDV ${esc(centralPdv)}</button>`:''}</div>`:!cutoverEditing?'<button id="centralResumePdv" class="primary" type="button">Abrir checklist deste PDV</button>':''}`;
 const personOptions=(roles,value)=>'<option value="">Não atribuído</option>'+(value&&!(data.people||[]).some(u=>u.id===value)?'<option value="'+esc(value)+'" selected disabled>Responsável inativo ou indisponível</option>':'')+(data.people||[]).filter(u=>roles.includes(u.role)).map(u=>`<option value="${esc(u.id)}" ${u.id===value?'selected':''}>${esc(u.name)} (${esc(ROLES[u.role])})</option>`).join('');
 $('centralAccountability').innerHTML=`<fieldset class="management-assignment"><legend>Responsáveis e planejamento</legend><div class="central-fields"><div><label for="centralExecutor">Executor do PDV</label><select id="centralExecutor" data-central-assignment="executor_id" ${!DECIDE||centralSaving?'disabled':''}>${personOptions(['admin','manager','operator'],assignment.executor_id)}</select></div><div><label for="centralValidator">Analista validador</label><select id="centralValidator" data-central-assignment="validator_id" ${!DECIDE||centralSaving?'disabled':''}>${personOptions(['admin','manager','operator'],assignment.validator_id)}</select></div><div><label for="centralWave">Onda do rollout</label><select id="centralWave" data-central-assignment="wave_id" ${!DECIDE||centralSaving?'disabled':''}><option value="">Sem onda</option>${(data.waves||[]).filter(w=>w.status!=='Cancelada'||w.id===assignment.wave_id).map(w=>`<option value="${esc(w.id)}" ${assignment.wave_id===w.id?'selected':''}>${esc(w.name)} · ${esc(w.due_date)}</option>`).join('')}</select></div><div><label for="centralPlanned">Planejado para (opcional)</label><input id="centralPlanned" data-central-assignment="planned_date" type="date" value="${esc(assignment.planned_date)}" ${!DECIDE||centralSaving?'disabled':''}></div></div><small>Sem data específica, prevalece o cronograma ou o prazo da onda. O validador atribuído concede o aceite; Administrador e Operador podem intervir.</small></fieldset>`;
 document.querySelectorAll('[data-central-org],[data-central-machine],[data-central-assignment]').forEach(input=>{
  const update=()=>{if(READONLY)return;if(input.dataset.centralAssignment)assignment[input.dataset.centralAssignment]=input.value;else if(input.dataset.centralOrg)data[input.dataset.centralOrg]=input.value;else if(m)m[input.dataset.centralMachine]=input.value;centralDirty=true;centralRevision++;centralSyncBadge()};
  input.addEventListener('input',update);input.addEventListener('change',update);
 });
 if($('centralBaseForm'))$('centralBaseForm').onsubmit=saveCentralBase;
 $('centralReloadBase').onclick=async()=>{if(centralSaving||saving)return;if((centralDirty||dirty)&&!confirm('Descartar os rascunhos do cadastro e do checklist e recarregar os dados salvos? Exporte o checklist antes se precisar guardar sua cópia.'))return;const id=currentId;centralDirty=false;dirty=false;centralData=null;await loadCentralBase(true);if(id&&cutoverEditing)await loadExecution(id)};

 if($('centralSaveBase'))$('centralSaveBase').disabled=centralSaving;
 if($('centralStartPdv'))$('centralStartPdv').onclick=startCentralPdv;
 if($('centralResumePdv'))$('centralResumePdv').onclick=()=>openCentralPdv(centralPdv);
 if($('centralGoLinx'))$('centralGoLinx').onclick=()=>centralGoDecision('linx');
 if($('centralGoOrion'))$('centralGoOrion').onclick=()=>centralGoDecision('orion');
 for(const [field,key] of [['centralNewNumber','new_pdv'],['centralLegacyNumber','legacy_pdv']]){
  $(field).addEventListener('input',event=>{
   const input=event.currentTarget;
   if(input.readOnly||input.disabled)return;
   m[key]=input.value;centralDirty=true;centralRevision++;$('centralIdentityError').textContent='';centralSyncBadge();
  });
 }
 if($('centralSaveIdentity'))$('centralSaveIdentity').onclick=saveCentralAll;
 centralSyncBadge();highlightCentralPdv();
}
function highlightCentralPdv(){
 document.querySelectorAll('#branchProgress [data-resume-pdv]').forEach(button=>{
  const m=branchProgress?.machines[Number(button.dataset.resumePdv)];if(!m)return;
  button.disabled=false;button.textContent='Selecionar PDV '+m.pdv;button.setAttribute('aria-pressed',String(m.pdv===centralPdv));
  button.closest('article').classList.toggle('pdv-selected',m.pdv===centralPdv);
  button.onclick=()=>openCentralPdv(m.pdv);
 });
 document.querySelectorAll('#branchProgress [data-remove-pdv]').forEach(button=>{
  const machine=branchProgress?.machines[Number(button.dataset.removePdv)];
  button.onclick=()=>{if(machine)removeCentralPdv(machine.pdv)};
 });
}
function removeCentralPdv(pdv){
 const data=centralData,branch=currentBranch();
 if(!DECIDE||!branch||data?.branch.id!==branch.id||!centralIdentityGuard())return;
 const remaining=data.machines.map(machine=>machine.pdv).filter(number=>number!==pdv);
 if(remaining.length===data.machines.length)return;
 if(!remaining.length){toast('Mantenha pelo menos um PDV previsto para esta filial.');return}
 modal(`<h2>Remover PDV ${esc(pdv)} do plano</h2>
  <p>O PDV ${esc(pdv)} da filial ${esc(branch.code)} sairá da meta e dos totais do Dashboard.</p>
  <p>Os registros serão preservados. Checklists salvos poderão ser consultados no histórico da filial.</p>
  <p id="centralRemoveError" class="sync-error" role="alert"></p>
  <div class="actions"><button type="button" id="centralRemoveCancel">Cancelar</button>
  <button type="button" id="centralRemoveConfirm" class="danger">Remover do plano</button></div>`);
 const dialog=$('modal'),confirmButton=$('centralRemoveConfirm'),cancelButton=$('centralRemoveCancel'),error=$('centralRemoveError');
 cancelButton.onclick=()=>dialog.close();
 confirmButton.onclick=async()=>{
  if(selectedBranchId!==branch.id||!centralIdentityGuard())return;
  confirmButton.disabled=true;
  cancelButton.disabled=true;
  try{
   await api('/api/branches/'+encodeURIComponent(branch.id)+'/pdv-plan','PUT',{pdvs:remaining,version:data.plan_version});
  }catch(e){
   error.textContent=e.status===409?'O plano mudou. Feche esta janela e recarregue os dados da filial.':e.message;
   confirmButton.disabled=false;
   cancelButton.disabled=false;
   return;
  }
  if(confirmButton.isConnected)dialog.close();
  toast('PDV '+pdv+' removido do plano da filial.');
  if(selectedBranchId!==branch.id)return;
  if(centralPdv===pdv||cutoverEditing&&Number(state.meta.pdv)===Number(pdv)){
   centralPdv='';
   clearCurrentCutover();
   showBranchPdvs();
  }
  centralData=null;
  try{await refreshList()}
  catch(e){toast('PDV removido. Atualize a filial para ver o plano salvo.')}
 };
}
async function saveCentralBase(event){event?.preventDefault();return saveCentralAll()}
const saveChecklistOnly=saveAndOfferPdf;
async function saveCentralAll(){
 if(READONLY||centralSaving||saving)return false;
 if(executionLoading){toast('Aguarde a abertura do PDV antes de salvar.');return false}
 const data=centralData,id=selectedBranchId,pdv=centralPdv;
 const m=data?.branch.id===id?centralMachine():null;
 if(!m){
  if(centralChecklistOpen()&&!currentRejection&&!centralDirty)return saveChecklistOnly();
  toast('Abra um checklist editável ou selecione um PDV previsto para salvar o cadastro.');
  return false;
 }
 const newNumber=(m.new_pdv??m.pdv).trim(),legacy=(m.legacy_pdv||'').trim();
 const validNumber=value=>/^[0-9]{1,4}$/.test(value)&&Number(value)>0;
 if(!validNumber(newNumber)||legacy&&!validNumber(legacy)){
  const invalidNew=!validNumber(newNumber);
  $('centralIdentityError').textContent='Informe um número de 1 a 9999 no campo '+(invalidNew?'PDV novo.':'PDV antigo ou deixe em branco.');
  $(invalidNew?'centralNewNumber':'centralLegacyNumber').focus();
  return false;
 }
 const check=centralChecklistOpen()&&!currentRejection&&centralPdvKey(state.meta.pdv)===pdv?{id:currentId,state:centralClone(state),version}:null;
 const assignment=(data.assignments||[]).find(a=>a.pdv===pdv)||{version:0,planned_date:''};
 const revision=editRevision,baseRevision=centralRevision;
 const {new_pdv, ...machine}=m;
 const body={pdv,new_pdv:newNumber,base:{regional:data.regional,gr:data.gr,version:data.version,plan_version:data.plan_version,machines:[{...machine,legacy_pdv:legacy}]},...(check?{checklist:check}:{}),...(DECIDE?{assignment:centralClone(assignment)}:{})};
 centralSaving=true;saving=true;$('centralNewNumber').disabled=true;$('centralLegacyNumber').disabled=true;if($('centralSaveIdentity'))$('centralSaveIdentity').disabled=true;centralSyncBadge();$('saveChecklist').disabled=true;if($('centralSaveBase'))$('centralSaveBase').disabled=true;
 try{
  const result=await api('/api/rollout/branches/'+encodeURIComponent(id)+'/save-all','POST',body);
  const savedPdv=result.pdv;centralPdv=savedPdv;
  if(result.checklist){version=result.checklist.version;if(result.checklist.meta)Object.assign(state.meta,result.checklist.meta);$('saved').textContent='Salvo por '+result.checklist.updated_by+' · '+new Date(result.checklist.updated_at).toLocaleString('pt-BR')}
  dirty=editRevision!==revision;centralDirty=centralRevision!==baseRevision;
  centralSaved=centralClone(result.base);centralData=centralClone(result.base);
  if(centralDirty){
   const editedData=centralClone(data);
   centralData.gr=editedData.gr;centralData.regional=editedData.regional;
   const edited=editedData.machines.find(x=>x.pdv===pdv),fresh=centralData.machines.find(x=>x.pdv===savedPdv);
   if(edited&&fresh){
    for(const key of ['installed_version','deployed_at','notes'])fresh[key]=edited[key];
    if(!check)fresh.status=edited.status;
   }
   const editedAssignment=editedData.assignments.find(a=>a.pdv===pdv);
   const freshAssignment=centralData.assignments.find(a=>a.pdv===savedPdv);
   if(editedAssignment&&freshAssignment)for(const key of ['executor_id','validator_id','wave_id','planned_date'])freshAssignment[key]=editedAssignment[key];
  }
  centralSaving=false;saving=false;conflict=false;
  if(savedPdv!==pdv&&check){const input=document.querySelector('[data-meta="branch"]');if(input)input.value=state.meta.branch}
  renderCentral();syncText(dirty||centralDirty?'Gravação confirmada. Há novas alterações na tela; use Salvar tudo novamente.':'Tudo salvo: cadastro, responsáveis e checklist.');
  if(!dirty&&!centralDirty){
   $('saveFeedback').textContent='PDV '+savedPdv+' salvo. Você pode selecionar outro equipamento ou continuar editando.';$('saveFeedback').hidden=false;
   if(check){
    const savedId=check.id,savedVersion=version;
    showBranchPdvs();modal('<div class="saved-icon">✓</div><h2>Tudo salvo!</h2><p>Cadastro, responsáveis e checklist do PDV '+esc(savedPdv)+' foram gravados juntos.</p><p class="notice">Pendências foram preservadas. Selecione o PDV na central para continuar.</p><div class="actions"><button id="backToSavedPdvs">Ver PDVs</button><button id="continueChecklist">Continuar editando</button><button id="downloadChecklist" class="primary">↓ PDF deste PDV</button></div><p id="pdfError" role="alert"></p>');
    $('backToSavedPdvs').onclick=()=>{$('modal').close();showBranchPdvs()};$('continueChecklist').onclick=()=>{$('modal').close();continueEditingChecklist()};
    $('downloadChecklist').onclick=()=>downloadChecklistPdf({id:savedId,version:savedVersion});
   }else toast('Cadastro e atribuições salvos.');
  }
  try{await refreshList()}catch(e){toast('Gravação confirmada. Não foi possível atualizar os PDVs: '+e.message)}
  return true;
 }catch(e){dirty=!!check||dirty;centralDirty=true;if(e.status===409)conflict=true;syncText('Não foi possível salvar tudo. Nenhuma parte desta operação foi gravada. '+e.message,true);if($('centralBaseError'))$('centralBaseError').textContent=e.message;if($('centralIdentityError'))$('centralIdentityError').textContent=e.message;toast('Seus rascunhos continuam na tela. '+e.message);return false}
 finally{centralSaving=false;saving=false;for(const field of ['centralNewNumber','centralLegacyNumber','centralSaveIdentity'])if($(field))$(field).disabled=READONLY;centralSyncBadge();if($('centralSaveBase'))$('centralSaveBase').disabled=READONLY;$('saveChecklist').disabled=READONLY||!currentId||!!currentRejection;$('saveChecklist').textContent='Salvar tudo'}
}
async function openCentralPdv(pdv){
 const machine=branchProgress?.machines.find(m=>m.pdv===pdv)||branchProgress?.machines.find(m=>m.pdv===centralPdvKey(pdv));if(!machine){toast('Não encontrei este PDV na filial selecionada. Atualize a lista e tente novamente.');return false}
 if(machine.execution){
  if(!await loadExecution(machine.execution.id))return false;
  centralPdv=machine.pdv;renderCentral();$('centralFormHost').scrollIntoView?.({behavior:'smooth',block:'start'});return true;
 }
 if(!allowDiscard())return false;
 dirty=false;clearCurrentCutover();showBranchPdvs();centralPdv=machine.pdv;renderCentral();return true;
}
async function startCentralPdv(){
 const b=currentBranch();if(!b||!DECIDE||!centralIdentityGuard())return;
 const existing=branchProgress?.machines.find(m=>m.pdv===centralPdv)?.execution;
 if(existing){await openCentralPdv(centralPdv);return}
 const pdv=centralPdv;const button=$('centralStartPdv');button.disabled=true;
 try{const r=await api('/api/cutovers','POST',{branch_id:b.id,pdv});await refreshList(r.id);await loadExecution(r.id);renderCentral();toast('PDV '+pdv+' iniciado. Marque os processos e use Salvar tudo.')}catch(e){toast(e.message);if($('centralStartPdv'))$('centralStartPdv').disabled=false}
}
async function centralGoDecision(key){
 if(!cutoverEditing){if(!await openCentralPdv(centralPdv))return}
 $('search').value='';$('filter').value='all';applyFilter();
 const el=$(key+'-decision');if(el){el.scrollIntoView?.({behavior:'smooth',block:'center'});el.focus({preventScroll:true})}
}
async function openCentralFromDashboard(id,pdv=null){
 if(!allowDiscard())return false;dirty=false;
 if(!await switchBranch(id))return false;
 $('modal').close();document.querySelector('[data-view="run"]').click();
 if(pdv)await openCentralPdv(pdv);else showBranchPdvs();
 renderCentral();return true;
}
async function centralOnBranchSaved(id){
 if(!$('cutoverWorkspace').classList.contains('hidden')&&id){await switchBranch(id);await loadCentralBase(true)}
}
function initCentral(){
 const workspace=$('cutoverWorkspace'),selection=$('cutoverSelection'),editor=$('cutoverEditor');
 const layout=document.createElement('div');layout.id='centralWorkspace';layout.className='central-layout';layout.hidden=true;
 layout.innerHTML='<section class="central-pdv-rail" aria-label="PDVs da filial"><div class="central-rail-heading"><span class="eyebrow">EQUIPAMENTOS DA FILIAL</span><button type="button" id="centralAddPdv">+ Adicionar PDV</button></div></section><div class="central-main"><div class="central-branch-summary"><strong id="centralBranchLabel"></strong><button type="button" id="centralEditBranch">Editar filial</button></div><div id="centralFormHost"></div></div>';
 selection.after(layout);layout.querySelector('.central-pdv-rail').append($('branchProgress'));layout.querySelector('.central-main').append(editor);
 $('centralEditBranch').onclick=()=>{if(centralIdentityGuard())branchForm(currentBranch())};
 $('centralAddPdv').onclick=()=>editBranchPdvPlan(selectedBranchId);
 const oldPlan=editBranchPdvPlan;
 editBranchPdvPlan=async function(id){
  if(!centralIdentityGuard())return;
  await oldPlan(id);
  const form=$('pdvPlanForm');if(!form)return;const submit=form.onsubmit;
  form.onsubmit=async e=>{await submit(e);if(!$('modal').open&&selectedBranchId===id){centralData=null;await refreshList();await loadCentralBase()}};
 };
 allowDiscard=function(){
  if(saving||centralSaving){toast('Aguarde o salvamento terminar.');return false}
  if(!dirty&&!centralDirty)return true;
  if(!confirm('Há alterações não salvas no cadastro ou checklist. Cancele para salvar antes de trocar. Deseja descartar e continuar?'))return false;
  if(centralDirty){centralDirty=false;centralData=centralClone(centralSaved);renderCentral()}
  return true;
 };
 const oldRefresh=refreshList;refreshList=async function(...args){const result=await oldRefresh(...args);await loadCentralBase();return result};
 const oldProgress=renderBranchProgress;renderBranchProgress=function(){oldProgress();highlightCentralPdv();if(!centralDirty)renderCentral()};
 const oldRender=render;render=function(){oldRender();if(!centralDirty)renderCentral()};
 saveAndOfferPdf=()=>saveCentralAll();$('saveChecklist').textContent='Salvar tudo';
 window.addEventListener('beforeunload',e=>{if(centralPending()){e.preventDefault();e.returnValue=''}});
 if($('dashboardExecutivePdf'))$('dashboardExecutivePdf').onclick=()=>downloadRolloutExecutivePdf($('dashboardExecutivePdf'));
 $('centralNewBranch').hidden=!DECIDE;$('centralNewBranch').onclick=()=>{if(centralIdentityGuard())branchForm()};
 const runNav=document.querySelector('[data-view="run"]');runNav.title='Central de Cutover';runNav.setAttribute('aria-label','Central de Cutover');const label=runNav.querySelector('.nav-label');if(label)label.textContent='Central de Cutover';
 $('acceptanceNav').hidden=true;
 renderCentral();
}
initCentral();
