(()=>{
 const paths={dashboard:'M3 3h7v7H3z M14 3h7v4h-7z M14 11h7v10h-7z M3 14h7v7H3z',run:'M9 5h11 M9 12h11 M9 19h11 M3 5l1 1 2-2 M3 12l1 1 2-2 M3 19l1 1 2-2',network:'M4 7h16 M16 3l4 4-4 4 M20 17H4 M8 13l-4 4 4 4',acceptance:'M12 3l8 4v5c0 5-8 9-8 9s-8-4-8-9V7z M8 12l3 3 5-6',branches:'M3 21h18 M5 21V5h14v16 M8 8h2 M14 8h2 M8 12h2 M14 12h2 M10 21v-5h4v5',schedule:'M4 5h16v16H4z M8 3v4 M16 3v4 M4 10h16 M8 14h3 M14 17h3',issues:'M12 3L2 21h20z M12 9v5 M12 17v1',history:'M3 11a9 9 0 1 1 2 7 M3 4v7h7 M12 7v5l3 2',reports:'M5 3h10l4 4v14H5z M15 3v5h4 M8 12h8 M8 16h5',users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75'};
 const icon=key=>`<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[key]||paths.run}"/></svg>`;
 const nav=document.querySelector('.nav'),aside=document.querySelector('aside');nav.id='appNavigation';nav.setAttribute('aria-label','Navegação principal');
 const groups=[['OPERAÇÃO',[['dashboardNav','dashboard','Dashboard'],['[data-view="run"]','run','Cutover'],['acceptanceNav','acceptance','Aceites']]],['GESTÃO',[['branchesNav','branches','Filiais'],['rolloutBaseNav','reports','Base de Rollout'],['[data-operation="schedule"]','schedule','Cronograma'],['[data-operation="issues"]','issues','Pendências'],['[data-operation="history"]','history','Histórico diário'],['reportsNav','reports','Relatórios']]],['ADMINISTRAÇÃO',[['usersNav','users','Usuários e acessos']]]];
 for(const [label,entries] of groups){const buttons=entries.map(([selector,key,text])=>{const b=selector.startsWith('[')?nav.querySelector(selector):document.getElementById(selector);if(!b)return null;b.innerHTML=icon(key)+`<span class="nav-label">${text}</span>`;b.title=text;b.setAttribute('aria-label',text);return b}).filter(Boolean);if(!buttons.length)continue;const heading=document.createElement('div');heading.className='nav-section-label';heading.textContent=label;nav.append(heading,...buttons)}
 const toggle=document.createElement('button');toggle.type='button';toggle.id='sidebarToggle';toggle.className='sidebar-toggle';toggle.setAttribute('aria-controls','appNavigation');toggle.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg><span class="toggle-label">Menu</span>';aside.prepend(toggle);
 const mobile=()=>matchMedia('(max-width: 700px)').matches;
 function sync(){const expanded=mobile()?document.body.classList.contains('mobile-menu-open'):!document.body.classList.contains('sidebar-collapsed');toggle.setAttribute('aria-expanded',String(expanded));toggle.setAttribute('aria-label',expanded?'Recolher menu':'Expandir menu');if(mobile()){nav.inert=!expanded}else nav.inert=false}
 try{if(localStorage.getItem('cutover-menu-compact')==='1')document.body.classList.add('sidebar-collapsed')}catch{}
 toggle.onclick=()=>{if(mobile())document.body.classList.toggle('mobile-menu-open');else{document.body.classList.toggle('sidebar-collapsed');try{localStorage.setItem('cutover-menu-compact',document.body.classList.contains('sidebar-collapsed')?'1':'0')}catch{}}sync()};
 nav.addEventListener('click',event=>{
  if(!mobile()||!event.target.closest('button'))return;
  document.body.classList.remove('mobile-menu-open');
  sync();
  window.scrollTo(0,0);
  toggle.focus({preventScroll:true});
 });
 window.addEventListener('resize',sync);
 document.addEventListener('keydown',event=>{
  if(event.key!=='Escape'||!mobile()||!document.body.classList.contains('mobile-menu-open'))return;
  document.body.classList.remove('mobile-menu-open');
  sync();
  toggle.focus({preventScroll:true});
 });
 sync();
})();
