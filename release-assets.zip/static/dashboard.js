let dashboardData=null,dashboardPage=1,dashboardRequest=0,dashboardSearchTimer;
async function showDashboard(){
 if(typeof hideOperations==='function')hideOperations();
 $('usersPage').classList.add('hidden');$('usersNav')?.classList.remove('active');
 ['cutoverWorkspace','branchesPage','reportsPage'].forEach(id=>$(id).classList.add('hidden'));$('dashboardPage').classList.remove('hidden');
 document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.id==='dashboardNav'));
 await refreshDashboard();
}
function dashboardQuery(){const args=new URLSearchParams({q:$('dashboardSearch').value.trim(),uf:$('dashboardUf').value});if($('dashboardFrom')?.value)args.set('from',$('dashboardFrom').value);if($('dashboardTo')?.value)args.set('to',$('dashboardTo').value);return args.toString()}
async function refreshDashboard(page=1){
 if(!Number.isInteger(page)||page<1)page=1;
 const sequence=++dashboardRequest;if(!dashboardData)$('rolloutHeadline').innerHTML='<div class="rollout-primary-stats">'+Array.from({length:6},()=>'<div class="skeleton-line"></div>').join('')+'</div>';$('dashboardMessage').textContent='Atualizando indicadores do rollout…';$('dashboardPdf').disabled=true;$('dashboardCsv').disabled=true;
 try{const data=await api('/api/dashboard?'+dashboardQuery()+'&compact=1&page='+page);if(sequence!==dashboardRequest)return;dashboardData=data;dashboardPage=data.pagination?.page||1;
 const uf=$('dashboardUf').value;$('dashboardUf').innerHTML='<option value="">Todas as UFs</option>'+data.ufs.map(u=>`<option>${esc(u)}</option>`).join('');$('dashboardUf').value=uf;
 $('dashboardMessage').textContent='Dados salvos · '+new Date(data.generated_at).toLocaleString('pt-BR')+' · Uma máquina por filial + número de PDV. O preenchimento ainda não salvo não entra na contagem.';
 renderDashboard();if(typeof renderRolloutBaseDashboard==='function')renderRolloutBaseDashboard(data);if(typeof drawManagementDashboard==='function')drawManagementDashboard(data.management);if(typeof refreshDashboardOperations==='function')refreshDashboardOperations(data.operations||null);$('dashboardPdf').disabled=false;$('dashboardCsv').disabled=false;
 }catch(e){if(sequence!==dashboardRequest)return;dashboardData=null;$('rolloutHeadline').innerHTML='';$('executiveDashboard').innerHTML='';$('rolloutBaseDashboard').innerHTML='';$('dashboardAttention').innerHTML='';$('dashboardMessage').textContent=e.message;$('dashboardCards').innerHTML='';$('dashboardStores').innerHTML='';$('dashboardEvolution').innerHTML='';document.querySelectorAll('[data-dashboard-focus]').forEach(b=>b.onclick=()=>dashboardMachines(b.dataset.dashboardFocus));
 $('dashboardProgress').innerHTML='';$('dashboardExceptions').hidden=true;}
}
function renderDashboard(){
 if(!dashboardData)return;const d=dashboardData,t=d.totals;
 $('dashboardCards').innerHTML=[['PDVs previstos',t.expected,'Meta das lojas ativas'],['Virados e Orion OK',t.ok,t.percent+'% do parque previsto'],['PDVs pendentes',t.pending,'Inclui os ainda não iniciados'],['Lojas completas',t.stores_ok,t.stores+' lojas no escopo']].map(([label,n,detail])=>`<button class="stat action-stat" data-dashboard-focus="${label}"><small>${label}</small><strong>${n}</strong><small>${detail} · Ver lista →</small></button>`).join('');
 document.querySelectorAll('[data-dashboard-focus]').forEach(b=>b.onclick=()=>dashboardMachines(b.dataset.dashboardFocus));
 $('dashboardProgress').innerHTML=`<div class="dashboard-progress-label"><b>${t.percent}% concluído</b><span>${t.ok} de ${t.expected} PDVs</span></div><div class="bar"><span style="width:${t.percent}%"></span></div><p class="muted">${t.stores_pending} loja(s) com pendências. Fora do escopo: ${d.excluded.inactive} inativa(s), ${d.excluded.opening_soon} a inaugurar e ${d.excluded.needs_review} vínculo(s) a revisar.</p>`;
 renderApprovalTrend($('dashboardEvolution'),d.approval_trend||[]);
 const pages=d.pagination?.pages||Math.max(1,Math.ceil(d.stores.length/25));dashboardPage=Math.max(1,Math.min(pages,dashboardPage));const stores=d.compact?d.stores:d.stores.slice((dashboardPage-1)*25,dashboardPage*25);
 $('dashboardStores').innerHTML=stores.length?`<div class="report-table-wrap"><table class="branch-table"><thead><tr><th>Loja</th><th>Evolução</th><th>Números dos PDVs</th><th>Ações</th></tr></thead><tbody>${stores.map(s=>`<tr><td><b>${esc(s.code)}</b><span>${esc(s.name)}</span><span>${esc([s.city,s.uf].filter(Boolean).join(' / '))}</span></td><td><strong>${s.ok} / ${s.expected} OK</strong><span>${s.pending} pendente(s)</span><div class="bar"><span style="width:${s.percent}%"></span></div></td><td><div class="pdv-chips">${s.machines.map(m=>`<span class="pdv-chip ${m.ok?'ok':'pending'}" title="${esc(m.status)}">PDV ${esc(m.pdv)} · ${m.ok?'OK':'Pendente'}</span>`).join('')}</div></td><td><div class="actions"><button data-dashboard-store="${esc(s.id)}">Ver PDVs</button>${DECIDE?`<button data-dashboard-plan="${esc(s.id)}">Ajustar PDVs</button>`:''}</div></td></tr>`).join('')}</tbody></table></div><div class="branch-pagination"><span>${d.totals.stores} loja(s) · Página ${dashboardPage} de ${pages}</span><div class="actions"><button id="dashboardPrevious" ${dashboardPage===1?'disabled':''}>Anterior</button><button id="dashboardNext" ${dashboardPage===pages?'disabled':''}>Próxima</button></div></div>`:'<div class="empty">Nenhuma filial ativa neste recorte. Cadastre ou ative as lojas para iniciar o acompanhamento.</div>';
 if(stores.length){$('dashboardPrevious').onclick=()=>d.compact?refreshDashboard(dashboardPage-1):(dashboardPage--,renderDashboard());$('dashboardNext').onclick=()=>d.compact?refreshDashboard(dashboardPage+1):(dashboardPage++,renderDashboard())}
 document.querySelectorAll('[data-dashboard-store]').forEach(b=>b.onclick=()=>dashboardStore(b.dataset.dashboardStore));document.querySelectorAll('[data-dashboard-plan]').forEach(b=>b.onclick=()=>dashboardPlan(b.dataset.dashboardPlan));
 if(typeof renderExecutiveDashboard==='function')renderExecutiveDashboard(d);
 $('dashboardExceptions').innerHTML=d.exceptions.length?`<h3>Numeração para revisar · ${d.totals.exceptions}</h3><p>Estes registros não entram na meta nem nos PDVs OK até a numeração corresponder ao plano da loja.</p><ul>${d.exceptions.slice(0,100).map(e=>`<li>${esc(e.code)} · PDV ${esc(e.pdv||'não informado')}: ${esc(e.reason)}</li>`).join('')}</ul>${d.totals.exceptions>100?'<p>Use a busca de loja para refinar essa lista.</p>':''}`:'';$('dashboardExceptions').hidden=!d.exceptions.length;
}
function renderApprovalTrend(container, trend, days=14, expanded=false, dimensions=null){
 if(!container)return;
 container.approvalTrendObserver?.disconnect();
 const rows=trend.slice(-days);
 const number=value=>Number(value||0).toLocaleString('pt-BR');
 const date=value=>value.split('-').reverse().slice(0,2).join('/');
 const last=rows.at(-1);
 const total=last?.cumulative_ok||0;
 const periodTotal=rows.reduce((sum,row)=>sum+row.count,0);
 const maximum=Math.max(1,total);
 const chartWidth=Math.max(280,Math.round(dimensions?.width||container.clientWidth||750));
 const chartHeight=Math.max(180,Math.round(dimensions?.height||210));
 const left=42,right=chartWidth-32,top=37,bottom=chartHeight-34,depth=8;
 const x=i=>left+(right-left)*(rows.length===1?1:i/Math.max(1,rows.length-1));
 const y=value=>bottom-(bottom-top)*value/maximum;
 const points=rows.map((row,i)=>x(i)+','+y(row.cumulative_ok));
 const ticks=[...new Set([0,Math.floor(maximum/2),maximum])];
 const dates=[...new Set([0,Math.round((rows.length-1)/3),Math.round((rows.length-1)*2/3),rows.length-1])];
 const graphicId='approval-'+(container.id||'trend').replace(/[^a-zA-Z0-9_-]/g,'');
 container.innerHTML=`<div class="approval-trend approval-trend-depth">
  <div class="approval-trend-header"><div><h2>Evolução acumulada do Orion OK</h2>
   <p>${last?`${date(rows[0].day)} a ${date(last.day)} · PDVs com data de aprovação identificada`:''}</p></div>
   <div class="actions" aria-label="Período da curva">${[7,14,30].map(period=>`<button type="button" data-trend-days="${period}" aria-pressed="${period===days}">${period} dias</button>`).join('')}${expanded?'':'<button type="button" data-trend-expand>⛶ Ampliar gráfico</button>'}</div>
  </div>
  ${last?`<div class="approval-trend-stage">
   <div class="approval-trend-summary"><div><span>Orion OK acumulado</span><strong>${number(total)} <small>PDVs</small></strong></div><div><span>Aprovações no período</span><strong>+${number(periodTotal)}</strong></div></div>
   <div class="approval-trend-plot"><svg class="approval-trend-chart" width="${chartWidth}" height="${chartHeight}" viewBox="0 0 ${chartWidth} ${chartHeight}" role="img" aria-label="Evolução acumulada de PDVs Orion OK, de ${date(rows[0].day)} a ${date(last.day)}. Total ${number(total)}.">
    <defs>
     <linearGradient id="${graphicId}-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#ffffff" stop-opacity=".18"/><stop offset="100%" stop-color="#ffffff" stop-opacity=".03"/></linearGradient>
     <linearGradient id="${graphicId}-line"><stop stop-color="#ffffff"/><stop offset="100%" stop-color="#ffffff"/></linearGradient>
     <linearGradient id="${graphicId}-side" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#b9c6d8" stop-opacity=".25"/><stop offset="100%" stop-color="#3a4354" stop-opacity=".08"/></linearGradient>
     <filter id="${graphicId}-glow" x="-20%" y="-100%" width="140%" height="300%"><feGaussianBlur stdDeviation="3"/></filter>
    </defs>
    <path d="M${left} ${bottom} H${right} L${right+10} ${bottom+depth} H${left+10} Z" fill="#4a4b61" opacity=".7"/>
    ${ticks.map(value=>`<path d="M${left} ${y(value)} H${right} l10 12" fill="none" stroke="#7b7e95" stroke-opacity=".3"/><text class="approval-axis" x="${left-12}" y="${y(value)+5}" text-anchor="end">${number(value)}</text>`).join('')}
    ${points.length?`<polygon points="${points.join(' ')} ${rows.map((row,i)=>(x(i)+10)+','+(y(row.cumulative_ok)+depth)).reverse().join(' ')}" fill="url(#${graphicId}-side)"/>`:''}
    <polygon points="${left},${bottom} ${points.join(' ')} ${right},${bottom}" fill="url(#${graphicId}-area)"/>
    <polyline points="${points.join(' ')}" class="approval-line-glow" stroke="url(#${graphicId}-line)" filter="url(#${graphicId}-glow)" fill="none" stroke-width="8" opacity=".32"/>
    <polyline points="${points.join(' ')}" class="approval-line-main" pathLength="1" fill="none" stroke="url(#${graphicId}-line)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
    ${rows.map((row,i)=>row.count>0?`<circle cx="${x(i)}" cy="${y(row.cumulative_ok)}" r="3" fill="#ffffff"/>`:'').join('')}
    ${dates.map(i=>`<text class="approval-axis" x="${x(i)}" y="${chartHeight-8}" text-anchor="middle">${date(rows[i].day)}</text>`).join('')}
    <line data-trend-guide stroke="#b5d7e5" stroke-opacity=".6" stroke-dasharray="3 5" y1="${top}" y2="${bottom+depth}"/>
    <circle data-trend-halo r="8" fill="#ffffff" opacity=".15"/>
    <circle data-trend-point r="4" fill="#ffffff" stroke="#ffffff" stroke-width="2"/>
    <g data-trend-label class="approval-trend-callout" aria-hidden="true"><rect width="102" height="27" rx="7" fill="#ffffff"/><text x="51" y="18" text-anchor="middle"></text></g>
   </svg></div>
   ${!total?'<p class="approval-trend-no-data">Sem aprovações com data identificada no recorte.</p>':''}
  </div>
  <div class="approval-trend-detail"><output data-trend-detail aria-live="polite"></output>
   <input type="range" min="0" max="${rows.length-1}" value="${rows.length-1}" aria-label="Selecionar dia da evolução"></div>`:
  '<p class="empty">Sem aprovações com data identificada no recorte.</p>'}
  <p class="muted dashboard-small">Conta os PDVs atualmente Orion OK por data de aprovação, incluindo o saldo anterior ao período.</p>
 </div>`;
 container.querySelectorAll('[data-trend-days]').forEach(button=>{
  button.onclick=()=>{renderApprovalTrend(container,trend,Number(button.dataset.trendDays),expanded);container.querySelector('[aria-pressed="true"]').focus()};
 });
 const expandButton=container.querySelector('[data-trend-expand]');
 if(expandButton)expandButton.onclick=()=>{
  const dialog=document.createElement('dialog');
  dialog.className='approval-trend-fullscreen';
  dialog.setAttribute('aria-label','Gráfico de evolução ampliado');
  dialog.innerHTML='<div class="approval-fullscreen-toolbar"><button type="button" data-trend-close autofocus>Fechar gráfico</button></div><div id="approvalExpandedChart"></div>';
  document.body.append(dialog);
  const previousOverflow=document.body.style.overflow;
  document.body.style.overflow='hidden';
  dialog.onclose=()=>{dialog.querySelector('#approvalExpandedChart').approvalTrendObserver?.disconnect();document.body.style.overflow=previousOverflow;dialog.remove();expandButton.focus()};
  dialog.querySelector('[data-trend-close]').onclick=()=>dialog.close();
  renderApprovalTrend(dialog.querySelector('#approvalExpandedChart'),trend,days,true);
  dialog.showModal();
 };
 const slider=container.querySelector('input[type="range"]');
 if(!slider)return;
 const svg=container.querySelector('svg');
 const guide=svg.querySelector('[data-trend-guide]'),point=svg.querySelector('[data-trend-point]');
 const halo=svg.querySelector('[data-trend-halo]'),label=svg.querySelector('[data-trend-label]');
 function select(index){
  const row=rows[index],position=x(index),height=y(row.cumulative_ok);
  guide.setAttribute('x1',position);guide.setAttribute('x2',position);
  for(const marker of [point,halo]){marker.setAttribute('cx',position);marker.setAttribute('cy',height)}
  label.setAttribute('transform',`translate(${Math.max(left,Math.min(right-102,position-51))},${Math.max(3,height-34)})`);
  label.querySelector('text').textContent=number(row.cumulative_ok)+' PDVs';
  slider.value=index;
  const description=`${date(row.day)} · ${number(row.cumulative_ok)} acumulados · +${number(row.count)} no dia`;
  container.querySelector('[data-trend-detail]').textContent=description;
  slider.setAttribute('aria-valuetext',description);
 }
 slider.oninput=()=>select(Number(slider.value));
 function selectAtPointer(event){
  const matrix=svg.getScreenCTM();
  if(!matrix)return;
  const cursor=svg.createSVGPoint();
  cursor.x=event.clientX;cursor.y=event.clientY;
  const local=cursor.matrixTransform(matrix.inverse());
  const index=Math.round((local.x-left)/(right-left)*(rows.length-1));
  select(Math.max(0,Math.min(rows.length-1,index)));
 }
 svg.onpointermove=event=>{if(event.pointerType==='mouse')selectAtPointer(event)};
 svg.onclick=selectAtPointer;
 select(Math.max(0,Math.min(rows.length-1,dimensions?.selectedIndex??rows.length-1)));
 if(typeof ResizeObserver!=='undefined'){
  const plot=container.querySelector('.approval-trend-plot');
  container.approvalTrendObserver=new ResizeObserver(([entry])=>{
   const {width,height}=entry.contentRect;
   if(width>0&&height>0&&(Math.abs(width-chartWidth)>1||Math.abs(height-chartHeight)>1)){
    renderApprovalTrend(container,trend,days,expanded,{width,height,selectedIndex:Number(slider.value)});
   }
  });
  container.approvalTrendObserver.observe(plot);
 }
}
async function dashboardStore(id){
 let s=dashboardData.stores.find(s=>s.id===id);if(!s&&dashboardData.compact){try{s=await api('/api/dashboard/store/'+encodeURIComponent(id))}catch(e){toast(e.message);return}}if(!s)return;
 modal(`<h2>${esc(s.code)} · ${esc(s.name)}</h2><p>${s.ok} de ${s.expected} PDVs Orion OK · ${s.pending} pendente(s)</p><div class="report-table-wrap"><table class="branch-table"><thead><tr><th>PDV</th><th>Situação atual</th><th>Processos</th><th>Execução</th></tr></thead><tbody>${s.machines.map(m=>`<tr><td><b>${esc(m.pdv)}</b></td><td>${esc(m.status)}${m.rejection_reason?'<br>'+esc(m.rejection_reason):''}</td><td>${m.completed} / 11</td><td>${m.cutover_id?`<button data-dashboard-open="${esc(m.cutover_id)}">Abrir</button>`:'Não iniciada'}</td></tr>`).join('')}</tbody></table></div>`);
 document.querySelectorAll('[data-dashboard-open]').forEach(b=>b.onclick=async()=>{if(!await switchBranch(id))return;await loadExecution(b.dataset.dashboardOpen);$('modal').close();document.querySelector('[data-view="run"]').click()});
}
async function dashboardPlan(id){return editBranchPdvPlan(id)}
async function editBranchPdvPlan(id){
 if(!DECIDE||!id)return;
 let s;try{s=await api('/api/branches/'+encodeURIComponent(id)+'/pdv-plan')}catch(e){toast(e.message);return}
 modal(`<h2>PDVs previstos · ${esc(s.code)}</h2><p>${esc(s.name)}</p><p>A loja pode ter mais de 5 PDVs. Adicione os equipamentos e salve para atualizar a meta no dashboard e nos relatórios.</p><form id="pdvPlanForm" class="form-stack"><div class="pdv-plan-toolbar"><strong id="pdvPlanTotal">${s.pdvs.length} PDVs previstos</strong><button type="button" id="appendPdvNumber">+ Adicionar próximo PDV</button></div><div class="row2"><div><label for="pdvPlanCount">Quantidade desejada</label><input id="pdvPlanCount" type="number" min="1" max="50" value="${s.pdvs.length}"></div><div><label>&nbsp;</label><button type="button" id="generatePdvNumbers">Aumentar até essa quantidade</button></div></div><label for="pdvPlanNumbers">Números reais dos PDVs (separados por vírgula)</label><input id="pdvPlanNumbers" value="${esc(s.pdvs.join(', '))}" required><p class="muted">Os botões acrescentam números sem remover os existentes. Para reduzir ou usar outra numeração, edite a lista. Os cutovers e checklists anteriores permanecem.</p><p id="pdvPlanError" role="alert" class="sync-error"></p><button class="primary" id="savePdvPlan">Salvar PDVs previstos</button></form>`);
 const values=()=>$('pdvPlanNumbers').value.split(/[,;]+/).map(v=>v.trim()).filter(Boolean);
 const display=list=>{$('pdvPlanNumbers').value=list.join(', ');$('pdvPlanTotal').textContent=list.length+' PDVs previstos';$('pdvPlanCount').value=list.length;$('pdvPlanError').textContent=''};
 function extend(target){
  const list=values();if(!Number.isInteger(target)||target<list.length||target>50){$('pdvPlanError').textContent='Informe uma quantidade maior ou igual à lista atual, até 50. Para reduzir, edite os números manualmente.';return}
  const numbers=list.map(v=>/^\d+$/.test(v)?Number(v):NaN);
  if(numbers.some(n=>!Number.isInteger(n)||n<1||n>9999)||new Set(numbers).size!==numbers.length){$('pdvPlanError').textContent='Confira a lista: use números únicos de 1 a 9999.';return}
  let next=Math.max(0,...numbers)+1;
  while(list.length<target){if(next>9999){next=1;while(numbers.includes(next))next++}list.push(String(next).padStart(2,'0'));numbers.push(next);next++}
  display(list);
 }
 $('appendPdvNumber').onclick=()=>extend(values().length+1);$('generatePdvNumbers').onclick=()=>extend(Number($('pdvPlanCount').value));$('pdvPlanNumbers').oninput=()=>{$('pdvPlanTotal').textContent=values().length+' PDVs previstos'};
 $('pdvPlanForm').onsubmit=async e=>{e.preventDefault();$('savePdvPlan').disabled=true;try{await api('/api/branches/'+id+'/pdv-plan','PUT',{pdvs:values(),version:s.plan_version});$('modal').close();if(!$('dashboardPage').classList.contains('hidden'))await refreshDashboard();toast('PDVs previstos atualizados. A loja já pode ter cutovers para os novos números.')}catch(err){$('pdvPlanError').textContent=err.message;$('savePdvPlan').disabled=false}};
}
async function executiveDownload(){
 if(!dashboardData)return;const button=$('dashboardPdf');button.disabled=true;
 try{const response=await fetch('/api/dashboard/executive.pdf?'+new URLSearchParams(dashboardData.filters),{credentials:'same-origin'});if(!response.ok){const data=await response.json();throw Error(data.error||'Falha ao gerar relatório.')}
 const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download='Relatorio_Executivo_PDV_Orion.pdf';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }catch(e){toast(e.message)}finally{button.disabled=false}
}
async function dashboardCsv(){
 if(!dashboardData)return;let exportData=dashboardData;try{if(exportData.compact)exportData=await api('/api/dashboard?'+dashboardQuery())}catch(e){toast(e.message);return}const rows=[['Filial','Loja','PDV','Situação','Orion OK','Atualizado em'],...exportData.machines.map(m=>[m.code,m.name,m.pdv,m.status,m.ok?'Sim':'Não',m.updated_at||''])];
 const cell=value=>{let text=String(value??'');if(/^\s*[=+@-]/.test(text))text="'"+text;return '"'+text.replace(/"/g,'""')+'"'};
 const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='Evolucao_PDV_Orion.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function initDashboard(){
 const nav=document.createElement('button');nav.id='dashboardNav';nav.textContent='▥ Dashboard';nav.onclick=showDashboard;document.querySelector('.nav').prepend(nav);
 $('dashboardSearch').oninput=()=>{clearTimeout(dashboardSearchTimer);dashboardSearchTimer=setTimeout(refreshDashboard,300)};$('dashboardUf').onchange=refreshDashboard;$('refreshDashboard').onclick=refreshDashboard;$('dashboardPdf').onclick=executiveDownload;$('dashboardCsv').onclick=dashboardCsv;
 showDashboard();
}
initDashboard();
async function dashboardMachines(focus,page=1){
 if(!dashboardData)return;
 const rolloutStatus={'PDVs implantados':'deployed','Pendentes de implantação':'undeployed'}[focus];
 if(dashboardData.compact||rolloutStatus){
  const status=rolloutStatus||{'Virados e Orion OK':'ok','PDVs pendentes':'pending','Lojas completas':'stores_ok','PDVs previstos':'all'}[focus]||focus;
  const query=new URLSearchParams(rolloutStatus?dashboardData.filters:dashboardQuery());
  modal(`<h2>${esc(focus)}</h2><div><label for="machineStoreSearch">Pesquisar loja</label><input id="machineStoreSearch" type="search" maxlength="200" placeholder="Digite o código ou nome da loja" autocomplete="off"></div><div id="machineResults" role="region" aria-label="PDVs encontrados" aria-busy="true"></div>`);
  const input=$('machineStoreSearch'),host=$('machineResults');
  let timer,revision=0;
  async function loadPage(nextPage){
   const requestRevision=++revision;
   host.setAttribute('aria-busy','true');
   host.innerHTML='<p role="status">Carregando PDVs…</p>';
   const params=new URLSearchParams(query);
   params.set('status',status);params.set('page',nextPage);params.set('store_q',input.value.trim());
   try{
    const result=await api('/api/dashboard/machines?'+params);
    if(requestRevision!==revision||!$('modal').open||$('machineResults')!==host)return;
    renderMachinePage(focus,result,!!rolloutStatus,host,loadPage);
   }catch(e){
    if(requestRevision===revision&&$('modal').open&&$('machineResults')===host)host.innerHTML='<p role="alert">'+esc(e.message)+'</p>';
   }finally{
    if(requestRevision===revision)host.setAttribute('aria-busy','false');
   }
  }
  input.oninput=()=>{clearTimeout(timer);revision++;host.setAttribute('aria-busy','true');host.innerHTML='<p role="status">Pesquisando lojas…</p>';timer=setTimeout(()=>loadPage(1),300)};
  input.focus();
  await loadPage(page);
  return;
 }
 const complete=new Set(dashboardData.stores.filter(s=>s.pending===0).map(s=>s.id));
 const machines=dashboardData.machines.filter(m=>focus==='Virados e Orion OK'?m.ok:focus==='PDVs pendentes'?!m.ok:focus==='Lojas completas'?complete.has(m.branch_id):true),pages=Math.max(1,Math.ceil(machines.length/40)),rows=machines.slice((page-1)*40,page*40);
 renderMachinePage(focus,{rows,page,pages,total:machines.length});
}
function renderMachinePage(focus,{rows,page,pages,total},rollout=false,host=null,navigate=null){
 const showOrganization=rollout&&focus==='PDVs implantados';
 const content=`<p role="status">${total} PDV(s) no recorte atual · Página ${page} de ${pages}</p><div class="report-table-wrap"><table class="branch-table${showOrganization?' machine-list-organization':''}"><thead><tr><th>Filial / PDV</th>${showOrganization?'<th>GGR</th><th>GR</th><th>DIV</th>':''}<th>Situação</th>${rollout?'<th>Versão</th><th>Data da implantação</th>':''}<th>Ação</th></tr></thead><tbody>${rows.map((m,i)=>`<tr><td><b>${esc(m.code)} · PDV ${esc(m.pdv)}</b><span>${esc(m.name)}</span></td>${showOrganization?`<td>${esc(m.ggr||'Não informado')}</td><td>${esc(m.gr||'Não informado')}</td><td>${esc(m.division||'Não informado')}</td>`:''}<td>${esc(m.status)}</td>${rollout?`<td>${esc(m.installed_version||'—')}</td><td>${m.deployed_at?esc(m.deployed_at.split('-').reverse().join('/')):'—'}</td>`:''}<td><button data-machine-index="${i}">Ver loja / execução</button></td></tr>`).join('')||`<tr><td colspan="${showOrganization?8:rollout?5:3}">Nenhum PDV neste filtro.</td></tr>`}</tbody></table></div><div class="actions"><button id="machinePrevious" ${page<=1?'disabled':''}>Anterior</button><button id="machineNext" ${page>=pages?'disabled':''}>Próxima</button></div>`;
 if(host)host.innerHTML=content;else modal(`<h2>${esc(focus)}</h2>`+content);
 $('machinePrevious').onclick=()=>navigate?navigate(page-1):dashboardMachines(focus,page-1);$('machineNext').onclick=()=>navigate?navigate(page+1):dashboardMachines(focus,page+1);
 document.querySelectorAll('[data-machine-index]').forEach(b=>b.onclick=async()=>{const m=rows[Number(b.dataset.machineIndex)];if(rollout){await openCentralFromDashboard(m.branch_id,m.pdv);return}if(!await switchBranch(m.branch_id))return;if(m.cutover_id)await loadExecution(m.cutover_id);$('modal').close();document.querySelector('[data-view="run"]').click();});
}
