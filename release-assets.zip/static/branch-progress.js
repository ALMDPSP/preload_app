function renderBranchProgress(){
 const el=$('branchProgress');if(!el)return;if(!branchProgress||branchProgress.branch.id!==selectedBranchId){el.innerHTML='';return}
 const data=branchProgress,t=data.totals;
 el.innerHTML=`<div class="pdv-overview-head"><div><h3>PDVs desta filial</h3><p>${t.saved} de ${t.expected} com checklist salvo · ${t.ok} concluído(s) · ${t.pending} pendente(s)</p></div><span class="scope-tag">Clique no PDV para continuar</span></div><div class="store-pdv-grid">${data.machines.map((m,i)=>{const r=m.execution;return `<article class="store-pdv-card ${r?.status==='Concluído'?'pdv-complete':''} ${r?.id===currentId&&cutoverEditing?'pdv-selected':''}"><div class="store-pdv-heading"><strong>PDV ${esc(m.pdv)}</strong><span class="badge ${r?.status==='Concluído'?'done':r?.status==='Rejeitado'||r?.status==='Bloqueado'?'blocked':'running'}">${esc(m.status)}</span></div>${r?`<p>${r.completed} de ${r.total} processos marcados</p><div class="bar"><span style="width:${r.completed/r.total*100}%"></span></div><small>Salvo em ${esc(new Date(r.updated_at).toLocaleString('pt-BR'))}<br>por ${esc(r.updated_by)}</small>`:'<p>Checklist ainda não iniciado.</p><small>Você pode começar agora e salvar mesmo com processos pendentes.</small>'}${!m.planned?'<small class="pdv-outside">Fora do plano da filial. O checklist ainda pode ser editado.</small>':''}<button type="button" data-resume-pdv="${i}" ${!r&&!DECIDE?'disabled':''}>${r?(READONLY||r.rejection_reason?'Abrir para consultar':'Abrir e editar'):'Iniciar PDV '+esc(m.pdv)}</button>${DECIDE&&m.planned?`<button type="button" class="pdv-remove" data-remove-pdv="${i}" aria-label="Remover PDV ${esc(m.pdv)} do plano">Remover PDV</button>`:''}${OPERATIONS_ADMIN&&r?`<button type="button" class="pdv-remove" data-delete-execution="${i}" aria-label="Excluir cutover do PDV ${esc(m.pdv)}">Excluir cutover</button>`:''}</article>`}).join('')}</div><p class="muted pdv-help">Pendências não impedem salvar. Você poderá buscar a filial novamente, abrir o mesmo PDV e continuar de onde parou. Orion OK exige os processos e os aceites completos.</p>`;
 el.querySelectorAll('[data-resume-pdv]').forEach(b=>b.onclick=async()=>{const m=data.machines[Number(b.dataset.resumePdv)];if(m.execution){if(await loadExecution(m.execution.id)){$('context').scrollIntoView?.({behavior:'smooth',block:'start'})}}else startBoundCutover(m.pdv)});
 el.querySelectorAll('[data-delete-execution]').forEach(button=>{
  button.onclick=()=>confirmCutoverDeletion(data.machines[Number(button.dataset.deleteExecution)].execution);
 });
 if($('editingPdvLabel'))$('editingPdvLabel').textContent='Editando '+(state.meta.branch||'checklist do PDV');
}
function showBranchPdvs(discard=false){
 if(saving){toast('Aguarde o salvamento terminar.');return false}
 if(discard&&!allowDiscard())return false;
 if(discard)dirty=false;
 cutoverEditing=false;$('execution').value='';updateCutoverActions();$('cutoverEditor').classList.add('hidden');renderBranchProgress();$('cutoverSelection').scrollIntoView?.({behavior:'smooth',block:'start'});$('cutoverSelectionTitle').focus?.({preventScroll:true});return true;
}
function continueEditingChecklist(){cutoverEditing=true;$('execution').value=currentId||'';updateCutoverActions();$('cutoverEditor').classList.remove('hidden');renderBranchProgress();$('context').scrollIntoView?.({behavior:'smooth',block:'start'})}
