let operationsData=null,operationsTab='schedule',operationsRequest=0,operationsPageNumber=1,historyRows=[],dashboardOpsRequest=0;
const OP_PRIORITIES=['Baixa','Normal','Alta','Crítica'],OP_STATUSES=['Aberta','Em tratamento','Resolvida'];
function hideOperations(){if(typeof hideRolloutBase==='function')hideRolloutBase();if($('operationsPage'))$('operationsPage').classList.add('hidden');document.querySelectorAll('[data-operation]').forEach(b=>b.classList.remove('active'))}
async function showOperations(tab='schedule',quick=''){
 if(typeof hideRolloutBase==='function')hideRolloutBase();
 operationsTab=tab;operationsPageNumber=1;operationsRequest++;['cutoverWorkspace','branchesPage','reportsPage','dashboardPage','usersPage'].forEach(id=>$(id).classList.add('hidden'));$('operationsPage').classList.remove('hidden');
 document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.operation===tab));
 $('operationsTitle').textContent={schedule:'Cronograma do rollout',issues:'Central de pendências',history:'Histórico diário'}[tab];$('operationFilters').hidden=tab==='history';$('historyFilters').hidden=tab!=='history';$('operationAdd').hidden=tab==='history'||(tab==='schedule'?!DECIDE:READONLY);$('operationAdd').textContent=tab==='schedule'?'+ Planejar PDV':'+ Registrar pendência';$('operationQuick').value=quick;
 $('scheduleImportButton').hidden=tab!=='schedule'||!DECIDE;
 $('operationTowerField').hidden=tab!=='issues';
 if(tab==='history'){await refreshHistory();return}
 const sequence=++operationsRequest;$('operationsMessage').textContent='Carregando informações salvas…';$('operationsTable').innerHTML='<div class="skeleton-line"></div>';
 try{const data=await api('/api/operations/overview');if(sequence!==operationsRequest)return;operationsData=data;if(typeof updateGuidedChecklist==='function')updateGuidedChecklist();$('operationsMessage').textContent='Atualizado em '+new Date(data.generated_at).toLocaleString('pt-BR')+'. Planejamento e pendências não alteram os aceites do checklist.';renderOperations()}
 catch(e){if(sequence!==operationsRequest)return;$('operationsMessage').textContent=e.message;$('operationsTable').innerHTML=''}
}
function filteredOperations(){
 if(!operationsData)return [];const q=reportNormalize($('operationSearch').value),quick=$('operationQuick').value,tower=$('operationTower').value;
 let rows=operationsData[operationsTab]||[];
 rows=rows.filter(r=>reportNormalize([r.code,r.name,r.pdv,r.owner,r.title,r.status,r.priority,r.tower].join(' ')).includes(q));
 if(operationsTab==='issues'&&tower)rows=rows.filter(r=>tower==='unassigned'?!r.tower:r.tower===tower);
 if(quick==='overdue')rows=rows.filter(r=>operationsTab==='schedule'?r.status==='Atrasado':r.overdue);
 if(quick==='pending')rows=rows.filter(r=>operationsTab==='schedule'?!['Concluído','Fora do escopo'].includes(r.status):r.status!=='Resolvida');
 if(quick==='done')rows=rows.filter(r=>operationsTab==='schedule'?r.status==='Concluído':r.status==='Resolvida');
 return rows;
}
function renderOperations(){
 if(!operationsData||operationsTab==='history')return;
 const rows=filteredOperations(),pages=Math.max(1,Math.ceil(rows.length/30));operationsPageNumber=Math.max(1,Math.min(operationsPageNumber,pages));const current=rows.slice((operationsPageNumber-1)*30,operationsPageNumber*30);
 const totals=operationsData.metrics;$('operationsCards').innerHTML=operationsTab==='schedule'?opCards([['PDVs planejados',totals.scheduled],['Atrasados',totals.overdue_schedule],['No filtro',rows.length]]):opCards([['Pendências abertas',totals.open_issues],['Prazo vencido',totals.overdue_issues],['No filtro',rows.length]]);
 $('operationsTable').innerHTML=rows.length?`<div class="report-table-wrap"><table class="branch-table"><thead><tr><th>Loja / PDV</th><th>${operationsTab==='schedule'?'Planejamento':'Pendência'}</th><th>Responsável / Prazo</th><th>Situação</th><th>Ações</th></tr></thead><tbody>${current.map((r,i)=>`<tr><td><b>${esc(r.code)} · PDV ${esc(r.pdv)}</b><span>${esc(r.name)}</span></td><td>${operationsTab==='schedule'?`Início: ${opDate(r.start_date)}<br>Previsto: ${opDate(r.due_date)}${r.completed_at?'<br>'+(r.completion_reference?'Referência estimada: ':'Concluído: ')+esc(new Date(r.completed_at).toLocaleDateString('pt-BR')):''}`:`<b>${esc(r.title)}</b><span>Prioridade ${esc(r.priority)}</span><span>${esc(r.tower||'Torre não informada')}</span>`}</td><td>${esc(r.owner)}<span>${opDate(r.due_date)}</span></td><td><span class="badge ${r.status==='Atrasado'||r.overdue?'blocked':r.status==='Concluído'||r.status==='Resolvida'?'done':'running'}">${esc(r.status)}</span>${r.overdue?'<span class="due-alert">Prazo vencido</span>':''}${r.machine_status?'<span>'+esc(r.machine_status)+'</span>':''}</td><td><div class="actions"><button data-operation-row="${i}">${(operationsTab==='schedule'?DECIDE:!READONLY)?'Abrir / editar':'Consultar'}</button>${operationsTab==='schedule'&&r.cutover_id?`<button data-schedule-open="${i}">Cutover</button>`:''}${operationsTab==='issues'&&OPERATIONS_ADMIN?`<button class="danger" data-delete-issue="${i}">Excluir</button>`:''}</div></td></tr>`).join('')}</tbody></table></div><div class="branch-pagination"><span>${rows.length} registro(s) · Página ${operationsPageNumber} de ${pages}</span><div class="actions"><button id="operationPrevious" ${operationsPageNumber===1?'disabled':''}>Anterior</button><button id="operationNext" ${operationsPageNumber===pages?'disabled':''}>Próxima</button></div></div>`:'<div class="empty"><b>Nenhum registro neste filtro.</b><p>Use o botão acima para planejar um PDV ou registrar uma pendência.</p></div>';
 if(rows.length){$('operationPrevious').onclick=()=>{operationsPageNumber--;renderOperations()};$('operationNext').onclick=()=>{operationsPageNumber++;renderOperations()}}
 document.querySelectorAll('[data-delete-issue]').forEach(b=>b.onclick=()=>deleteIssue(current[Number(b.dataset.deleteIssue)]));
 document.querySelectorAll('[data-operation-row]').forEach(b=>b.onclick=()=>operationsTab==='schedule'?scheduleForm(current[Number(b.dataset.operationRow)]):issueForm(current[Number(b.dataset.operationRow)]));document.querySelectorAll('[data-schedule-open]').forEach(b=>b.onclick=async()=>{const r=current[Number(b.dataset.scheduleOpen)];if(!await switchBranch(r.branch_id))return;await loadExecution(r.cutover_id);document.querySelector('[data-view="run"]').click()});
}
function opCards(values){return values.map(([label,n])=>`<div class="stat"><small>${label}</small><strong>${n}</strong></div>`).join('')}
function opDate(value){return value?esc(value.slice(0,10).split('-').reverse().join('/')):'Não informado'}
function operationStoreFields(row){const branch=registeredBranches.find(b=>b.id===row?.branch_id);return `<div class="row2"><div><label for="opBranch">Filial *</label><input id="opBranch" list="opBranches" value="${esc(row?.code||branch?.code||'')}" placeholder="Digite o código da filial" ${row?'readonly':''} required autocomplete="off"><datalist id="opBranches">${registeredBranches.map(b=>`<option value="${esc(b.code)}">${esc(b.name)}</option>`).join('')}</datalist></div><div><label for="opPdv">Número do PDV *</label><input id="opPdv" value="${esc(row?.pdv||'01')}" maxlength="12" ${row?'readonly':''} required></div></div>`}
function operationBranchId(){const code=$('opBranch').value.trim().toUpperCase();const branch=registeredBranches.find(b=>b.code.toUpperCase()===code);if(!branch)throw Error('Selecione uma filial cadastrada pelo código.');return branch.id}
async function scheduleForm(row=null){
 if(!registeredBranches.length)await refreshBranches();const readonly=!DECIDE;
 modal(`<h2>${row?'Planejamento do PDV':'Planejar PDV'}</h2><form id="scheduleForm" class="form-stack">${operationStoreFields(row)}<label for="opOwner">Responsável *</label><input id="opOwner" maxlength="120" value="${esc(row?.owner||document.body.dataset.userName)}" required><div class="row2"><div><label for="opStart">Início previsto</label><input id="opStart" type="date" value="${esc(row?.start_date||'')}"></div><div><label for="opDue">Prazo de conclusão *</label><input id="opDue" type="date" value="${esc(row?.due_date||'')}" required></div></div><label for="opNotes">Observações</label><textarea id="opNotes" maxlength="2000">${esc(row?.notes||'')}</textarea><p class="muted">A situação realizada é calculada pelo checklist salvo. O prazo não libera GO nem marca processos.</p><p id="opFormError" class="sync-error" role="alert"></p>${readonly?'':`<div class="actions"><button class="primary" id="opSave">Salvar planejamento</button>${row?'<button type="button" class="danger" id="opDelete">Remover planejamento</button>':''}</div>`}</form>`);
 if(readonly){$('scheduleForm').querySelectorAll('input,textarea').forEach(e=>e.disabled=true);return}
 $('scheduleForm').onsubmit=async e=>{e.preventDefault();$('opSave').disabled=true;try{await api('/api/operations/schedule','PUT',{branch_id:operationBranchId(),pdv:$('opPdv').value,owner:$('opOwner').value,start_date:$('opStart').value,due_date:$('opDue').value,notes:$('opNotes').value,version:row?.version||0});$('modal').close();await showOperations('schedule');toast('Planejamento salvo.')}catch(err){$('opFormError').textContent=err.message;$('opSave').disabled=false}};
 if(row)$('opDelete').onclick=async()=>{if(!confirm('Remover somente este planejamento? O checklist será mantido.'))return;try{await api('/api/operations/schedule','DELETE',{branch_id:row.branch_id,pdv:row.pdv,version:row.version});$('modal').close();await showOperations('schedule')}catch(err){$('opFormError').textContent=err.message}};
}
async function deleteIssue(row){
 if(!OPERATIONS_ADMIN)return;
 modal(`<h2>Excluir pendência</h2><p>Confirma excluir <b>${esc(row.title)}</b> da filial <b>${esc(row.code)}</b>, PDV <b>${esc(row.pdv)}</b>?</p><p class="muted">Esta exclusão é permanente. O checklist e os aceites serão mantidos. A ação ficará registrada no histórico de auditoria.</p><p id="deleteIssueError" class="sync-error" role="alert"></p><div class="actions"><button id="cancelIssueDelete">Cancelar</button><button id="confirmIssueDelete" class="danger">Excluir pendência</button></div>`);
 $('cancelIssueDelete').onclick=()=>$('modal').close();
 $('confirmIssueDelete').onclick=async()=>{const button=$('confirmIssueDelete');button.disabled=true;try{await api('/api/operations/issues/'+encodeURIComponent(row.id),'DELETE',{version:row.version});$('modal').close();await showOperations('issues',$('operationQuick').value);toast('Pendência excluída.')}catch(e){$('deleteIssueError').textContent=e.message;button.disabled=false}};
}
async function issueForm(row=null){
 if(!registeredBranches.length)await refreshBranches();const readonly=READONLY;
 modal(`<h2>${row?'Pendência da operação':'Registrar pendência'}</h2><form id="issueForm" class="form-stack">${operationStoreFields(row)}<label for="issueTitle">O que impede o avanço? *</label><input id="issueTitle" maxlength="160" value="${esc(row?.title||'')}" required><label for="issueDescription">Descrição</label><textarea id="issueDescription" maxlength="2000">${esc(row?.description||'')}</textarea><label for="issueImpact">Impacto na operação (opcional)</label><textarea id="issueImpact" maxlength="1000" placeholder="Ex.: venda parada, impressão indisponível">${esc(row?.impact||'')}</textarea><label for="issueTower">Torre em análise</label><select id="issueTower"><option value="">Não informada</option>${Array.from($('operationTower').options).filter(option=>option.value&&option.value!=='unassigned').map(option=>`<option value="${esc(option.value)}" ${option.value===row?.tower?'selected':''}>${esc(option.label)}</option>`).join('')}</select><label for="opOwner">Responsável pela solução *</label><input id="opOwner" maxlength="120" value="${esc(row?.owner||document.body.dataset.userName)}" required><div class="row2"><div><label for="opDue">Prazo *</label><input id="opDue" type="date" value="${esc(row?.due_date||'')}" required></div><div><label for="issuePriority">Prioridade</label><select id="issuePriority">${OP_PRIORITIES.map(p=>`<option ${p===(row?.priority||'Normal')?'selected':''}>${p}</option>`).join('')}</select></div></div><label for="issueStatus">Situação</label><select id="issueStatus">${OP_STATUSES.map(s=>`<option ${s===(row?.status||'Aberta')?'selected':''}>${s}</option>`).join('')}</select><label for="issueResolution">Resolução (obrigatória ao resolver)</label><textarea id="issueResolution" maxlength="2000">${esc(row?.resolution||'')}</textarea><p class="muted">Resolver a pendência não conclui automaticamente o processo nem libera o aceite.</p><p id="opFormError" class="sync-error" role="alert"></p>${readonly?'':'<button id="opSave" class="primary">Salvar pendência</button>'}</form>`);
 if(readonly){$('issueForm').querySelectorAll('input,textarea,select').forEach(e=>e.disabled=true);return}
 $('issueForm').onsubmit=async e=>{e.preventDefault();$('opSave').disabled=true;try{const body={branch_id:operationBranchId(),pdv:$('opPdv').value,title:$('issueTitle').value,description:$('issueDescription').value,owner:$('opOwner').value,due_date:$('opDue').value,priority:$('issuePriority').value,status:$('issueStatus').value,resolution:$('issueResolution').value,impact:$('issueImpact').value,tower:$('issueTower').value,version:row?.version||0};await api('/api/operations/issues'+(row?'/'+row.id:''),row?'PUT':'POST',body);$('modal').close();if(typeof refreshCentralIssues==='function'&&!$('cutoverWorkspace').classList.contains('hidden'))await refreshCentralIssues();else await showOperations('issues');toast('Pendência registrada.')}catch(err){$('opFormError').textContent=err.message;$('opSave').disabled=false}};
}
async function refreshHistory(){
 const sequence=++operationsRequest;$('operationAdd').hidden=true;$('operationsMessage').textContent='Carregando consolidados…';$('operationsTable').innerHTML='';$('operationsCards').innerHTML='';
 try{const data=await api('/api/operations/history?'+new URLSearchParams({from:$('historyFrom').value,to:$('historyTo').value}));if(sequence!==operationsRequest)return;historyRows=data.rows;
 $('operationsMessage').textContent='Visão global das filiais ativas. O dia atual é provisório e atualiza com os dados salvos. Dias anteriores ficam preservados. Dias sem registro não são estimados.';
 const first=data.rows[0],last=data.rows[data.rows.length-1];$('operationsCards').innerHTML=opCards([['Dias registrados',data.rows.length],['Variação de PDVs OK',first&&last?last.ok-first.ok:0],['Último avanço',last?last.percent+'%':'—']]);
 $('operationsTable').innerHTML=comparisonCards(data.comparisons||[])+snapshotChart(data.rows)+(data.rows.length?`<div class="report-table-wrap"><table class="branch-table"><thead><tr><th>Dia</th><th>PDVs previstos</th><th>Orion OK</th><th>Pendentes</th><th>Avanço</th><th>Registro</th></tr></thead><tbody>${data.rows.map(r=>`<tr><td>${opDate(r.day)}</td><td>${r.expected}</td><td>${r.ok}</td><td>${r.pending}</td><td>${r.percent}%</td><td>${r.provisional?'Provisório':'Consolidado'}<span>${esc(new Date(r.captured_at).toLocaleString('pt-BR'))}</span></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">Ainda não há consolidados neste período. O histórico começa a partir desta versão.</div>');
 }catch(e){if(sequence===operationsRequest)$('operationsMessage').textContent=e.message}
}
function comparisonCards(periods){return periods.length?'<h2>Comparativo semanal e mensal · calendário atual</h2><p class="muted">Estes cartões usam o calendário atual; o gráfico e a tabela usam o período consultado. Variação líquida de PDVs OK entre as datas registradas. Mudanças no parque previsto também podem alterar o resultado. Sem registro de base, não estimamos.</p><div class="stats comparison-stats">'+periods.map(p=>`<div class="stat"><small>${esc(p.label)}</small><strong>${p.ok_delta===null?'—':(p.ok_delta>0?'+':'')+p.ok_delta}</strong><small>${p.ok_delta===null?'Sem base para comparar':opDate(p.baseline_day)+' → '+opDate(p.last_day)} · ${p.days_recorded} dia(s) registrado(s)</small></div>`).join('')+'</div>':''}
function snapshotChart(rows){
 if(!rows.length)return '';const first=Date.parse(rows[0].day+'T12:00:00Z'),last=Date.parse(rows[rows.length-1].day+'T12:00:00Z'),x=r=>45+660*(Date.parse(r.day+'T12:00:00Z')-first)/Math.max(1,last-first),y=r=>175-140*r.percent/100;
 return `<svg class="dashboard-chart" viewBox="0 0 750 220" role="img" aria-label="Percentual diário consolidado"><title>Evolução diária do percentual de PDVs Orion OK</title><line x1="45" y1="175" x2="705" y2="175" stroke="#d3e2dc"/><text x="0" y="38">100%</text><text x="12" y="179">0%</text><polyline points="${rows.map(r=>x(r)+','+y(r)).join(' ')}" fill="none" stroke="#31527b" stroke-width="3"/>${rows.map(r=>`<circle cx="${x(r)}" cy="${y(r)}" r="3" fill="#31527b"><title>${esc(r.day)} · ${r.ok}/${r.expected} OK (${r.percent}%)${r.provisional?' · provisório':''}</title></circle>`).join('')}<text x="45" y="205">${esc(rows[0].day)}</text><text x="705" y="205" text-anchor="end">${esc(rows[rows.length-1].day)}</text></svg>`;
}
async function refreshDashboardOperations(supplied=null){
 const sequence=++dashboardOpsRequest;$('dashboardAttention').innerHTML='<div class="skeleton-line"></div>';
 try{const data=supplied||await api('/api/operations/overview');if(sequence!==dashboardOpsRequest)return;if(data.issues&&data.schedule)operationsData=data;if(typeof updateGuidedChecklist==='function')updateGuidedChecklist();const goal=data.goal,m=data.metrics;
 $('dashboardAttention').innerHTML=`<div class="section-top"><div><div class="eyebrow">METAS E ATENÇÃO · VISÃO GLOBAL</div><h2>Prioridades da operação</h2></div>${DECIDE?'<button id="editWeeklyGoal">Definir meta semanal</button>':''}</div><div class="stats operational-stats"><button class="stat action-stat" id="weeklyGoalCard"><small>OK aprovados na semana</small><strong>${goal.achieved}${goal.target?' / '+goal.target:''}</strong><small>${goal.target?goal.percent+'% da meta':'Meta ainda não definida'}</small></button><button class="stat action-stat" data-quick-op="schedule"><small>PDVs com prazo vencido</small><strong>${m.overdue_schedule}</strong><small>Abrir cronograma atrasado →</small></button><button class="stat action-stat" data-quick-op="issues"><small>Pendências abertas</small><strong>${m.open_issues}</strong><small>${m.overdue_issues} com prazo vencido →</small></button></div><p class="muted dashboard-small">Semana de ${opDate(goal.week_start)}. Contagem de aprovações vigentes com data identificada no histórico; referências legadas estimadas não entram na meta semanal.</p>`;
 $('weeklyGoalCard').onclick=()=>DECIDE?weeklyGoalForm(goal):showOperations('history');if($('editWeeklyGoal'))$('editWeeklyGoal').onclick=()=>weeklyGoalForm(goal);document.querySelectorAll('[data-quick-op]').forEach(b=>b.onclick=()=>showOperations(b.dataset.quickOp,b.dataset.quickOp==='schedule'?'overdue':'pending'));
 }catch(e){if(sequence===dashboardOpsRequest)$('dashboardAttention').textContent='Não foi possível carregar metas e pendências: '+e.message}
}
function weeklyGoalForm(goal){
 if(!DECIDE)return;
 modal(`<h2>Meta semanal de PDVs Orion OK</h2><p>Semana iniciada em ${opDate(goal.week_start)}. A meta é global para as filiais ativas.</p><form id="weeklyGoalForm" class="form-stack"><label for="goalTarget">Quantidade de PDVs *</label><input id="goalTarget" type="number" min="0" max="100000" step="1" value="${goal.target}" required><p class="muted">Use 0 para deixar a semana sem meta. A meta não altera os PDVs previstos das lojas.</p><p id="goalError" class="sync-error" role="alert"></p><button id="goalSave" class="primary">Salvar meta</button></form>`);
 $('weeklyGoalForm').onsubmit=async e=>{e.preventDefault();$('goalSave').disabled=true;try{await api('/api/operations/goals/'+goal.week_start,'PUT',{target:Number($('goalTarget').value),version:goal.version});$('modal').close();await refreshDashboardOperations();toast('Meta semanal salva.')}catch(err){$('goalError').textContent=err.message;$('goalSave').disabled=false}};
}
function exportOperations(){
 const rows=operationsTab==='history'?[['Dia','PDVs previstos','OK','Pendentes','Avanço (%)','Registro'],...historyRows.map(r=>[r.day,r.expected,r.ok,r.pending,r.percent,r.provisional?'Provisório':'Consolidado'])]:[['Filial','Loja','PDV','Responsável','Prazo','Situação','Prioridade','Descrição',...(operationsTab==='issues'?['Torre em análise']:[])],...filteredOperations().map(r=>[r.code,r.name,r.pdv,r.owner,r.due_date,r.status,r.priority||'',r.title||r.notes||'',...(operationsTab==='issues'?[r.tower||'']:[])])];
 const cell=v=>{let s=String(v??'');if(/^\s*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download={schedule:'Cronograma',issues:'Pendencias',history:'Historico_Diario'}[operationsTab]+'.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function initOperations(){
 const nav=document.querySelector('.nav');for(const [key,label] of [['schedule','Cronograma'],['issues','Pendências'],['history','Histórico diário']]){const b=document.createElement('button');b.dataset.operation=key;b.textContent=label;b.onclick=()=>showOperations(key);nav.append(b)}
 const now=new Date(),start=new Date(now);start.setDate(start.getDate()-30);$('historyFrom').value=start.toISOString().slice(0,10);$('historyTo').value=now.toISOString().slice(0,10);
 $('scheduleImportButton').onclick=openScheduleImport;
 $('operationsRefresh').onclick=()=>showOperations(operationsTab,$('operationQuick').value);$('operationAdd').onclick=()=>operationsTab==='schedule'?scheduleForm():issueForm();$('operationSearch').oninput=()=>{operationsPageNumber=1;renderOperations()};$('operationQuick').onchange=()=>{operationsPageNumber=1;renderOperations()};$('operationTower').onchange=$('operationQuick').onchange;$('historyLoad').onclick=refreshHistory;$('operationsExport').onclick=exportOperations;
}
initOperations();

if(typeof dashboardData!=='undefined'&&dashboardData?.operations)refreshDashboardOperations(dashboardData.operations);

function openScheduleImport(){
 if(!DECIDE)return;
 modal(`<h2>Importar cronograma</h2>
  <p>Envie um arquivo .xlsx ou .csv com Filial, PDV, Responsável e Prazo. Início e Observações são opcionais.</p>
  <p class="muted">Use a primeira aba do Excel e informe datas como DD/MM/AAAA ou AAAA-MM-DD. Registros existentes serão pulados.</p>
  <p><a href="/api/operations/schedule/import-template" download>↓ Baixar modelo CSV</a></p>
  <form id="scheduleImportForm" class="form-stack">
   <label for="scheduleImportFile">Planilha do cronograma</label>
   <input type="file" id="scheduleImportFile" accept=".xlsx,.csv" required>
   <p id="scheduleImportError" role="alert" class="sync-error"></p>
   <button id="scheduleImportPreview" class="primary">Conferir planilha</button>
  </form>
  <div id="scheduleImportResult" aria-live="polite"></div>`);
 const form=$('scheduleImportForm'),input=$('scheduleImportFile'),result=$('scheduleImportResult');
 input.onchange=()=>{result.innerHTML='';$('scheduleImportError').textContent=''};
 form.onsubmit=async event=>{
  event.preventDefault();
  const file=input.files[0],button=$('scheduleImportPreview');
  if(!file)return;
  button.disabled=true;
  result.innerHTML='';
  const message=$('scheduleImportError');
  message.textContent='';
  try{
   const preview=await sendScheduleImport('preview',file);
   if(!result.isConnected||input.files[0]!==file)return;
   renderScheduleImport(preview,file,result,message);
  }catch(error){message.textContent=error.message}
  finally{button.disabled=false}
 };
}
async function sendScheduleImport(action,file){
 const form=new FormData();
 form.append('file',file);
 const response=await fetch('/api/operations/schedule/import/'+action,{method:'POST',headers:{'X-CSRF-Token':csrf},body:form});
 if(response.status===413)throw Error('A planilha excede o limite de 10 MB.');
 const data=await response.json().catch(()=>null);
 if(!response.ok||!data)throw Error(data?.error||'Não foi possível processar a planilha.');
 return data;
}
function renderScheduleImport(preview,file,container,message){
 const errors=preview.errors.map(error=>`<li>Linha ${error.line} · ${esc(error.message)}</li>`).join('');
 const labels={new:'Novo',existing:'Já cadastrado',invalid:'Corrigir'};
 container.innerHTML=`<p><b>${preview.new} novos</b> · ${preview.existing} já cadastrados · ${preview.error_count} erros</p>
  ${errors?`<div class="import-errors"><p>Corrija o arquivo e analise novamente.</p><ul>${errors}</ul></div>`:''}
  <div class="import-preview-table"><table class="branch-table"><thead><tr><th>Linha</th><th>Filial / PDV</th><th>Responsável</th><th>Prazo</th><th>Ação</th></tr></thead><tbody>
  ${preview.rows.map(row=>`<tr><td>${row.line}</td><td>${esc(row.code)} · ${esc(row.pdv)}</td><td>${esc(row.owner)}</td><td>${opDate(row.due_date)}</td><td>${labels[row.action]}</td></tr>`).join('')}
  </tbody></table></div><p class="muted">${preview.total} linha(s) no arquivo. Prévia de até 50 linhas.</p>
  <button class="primary" id="scheduleImportConfirm" ${preview.error_count||!preview.new?'disabled':''}>Confirmar importação</button>`;
 const button=$('scheduleImportConfirm');
 button.onclick=async()=>{
  button.disabled=true;
  $('scheduleImportFile').disabled=true;
  $('scheduleImportPreview').disabled=true;
  message.textContent='';
  try{
   const saved=await sendScheduleImport('confirm',file);
   if(container.isConnected)$('modal').close();
   if(operationsTab==='schedule'&&!$('operationsPage').classList.contains('hidden'))await showOperations('schedule');
   toast(`${saved.created} planejamento(s) importado(s) · ${saved.skipped} já cadastrado(s).`);
  }catch(error){
   message.textContent=error.message;
   button.disabled=false;
   if(container.isConnected){$('scheduleImportFile').disabled=false;$('scheduleImportPreview').disabled=false}
  }
 };
}
